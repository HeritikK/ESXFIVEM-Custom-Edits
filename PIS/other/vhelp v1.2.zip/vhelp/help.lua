/help ^0Shows this message.
/rules ^0Shows the server rules.