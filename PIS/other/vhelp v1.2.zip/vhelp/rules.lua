1) ^0Rule 1
2) ^0Rule 2
3) ^0Rule 3